package com.company;

public interface CanFly {
    void fly();
}
