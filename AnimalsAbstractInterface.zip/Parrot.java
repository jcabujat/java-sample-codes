package com.company;

public class Parrot extends Bird {

    public Parrot(String name) {
        super(name);
    }

}
